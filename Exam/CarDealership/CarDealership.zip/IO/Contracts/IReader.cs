﻿namespace CarDealership.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
