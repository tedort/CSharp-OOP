﻿namespace CarDealership.Models
{
    public class LegalEntityCustomer : Customer
    {
        public LegalEntityCustomer(string name) : base(name)
        {
        }
    }
}
