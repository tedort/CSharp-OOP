﻿namespace Vehicles.Models.Interfaces
{
    public interface IRefuellable
    {
        void Refuel(double amount);
    }
}
