﻿namespace Vehicles.Models.Interfaces
{
    public interface IDrivable
    {
        void Drive(double distance);
    }
}
