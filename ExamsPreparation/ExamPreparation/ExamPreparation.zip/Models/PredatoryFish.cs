﻿namespace NauticalCatchChallenge.Models
{
    public class PredatoryFish : Fish
    {
        public PredatoryFish(string name, double points) : base(name, points, 60)
        {
        }
    }
}
