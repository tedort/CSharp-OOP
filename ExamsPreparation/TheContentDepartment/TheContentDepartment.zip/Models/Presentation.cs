﻿namespace TheContentDepartment.Models
{
    public class Presentation : Resource
    {
        public Presentation(string name, string creator) : base(name, creator, 3)
        {
        }
    }
}
