﻿namespace BorderControl.Models
{
    public abstract class BaseEntity
    {
        public string Id { get; set; }
        public string Birthday { get; set; }
    }
}
