﻿namespace Restaurant
{
    public class HotBeverage : Beverage
    {
        public HotBeverage(string name, int price, double milliliters) : base(name, price, milliliters)
        {
        }
    }
}
