﻿namespace Restaurant
{
    public class Soup : Starter
    {
        public Soup(string name, int price, double grams) : base(name, price, grams)
        {
        }
    }
}
