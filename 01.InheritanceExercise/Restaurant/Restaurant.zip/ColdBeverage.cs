﻿namespace Restaurant
{
    public class ColdBeverage : Beverage
    {
        public ColdBeverage(string name, int price, double milliliters) : base(name, price, milliliters)
        {
        }
    }
}
