﻿namespace Restaurant
{
    public class Tea : HotBeverage
    {
        public Tea(string name, int price, double milliliters) : base(name, price, milliliters)
        {
        }
    }
}
