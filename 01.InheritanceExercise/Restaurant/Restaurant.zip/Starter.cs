﻿namespace Restaurant
{
    public class Starter : Food
    {
        public Starter(string name, int price, double grams) : base(name, price, grams)
        {
        }
    }
}
